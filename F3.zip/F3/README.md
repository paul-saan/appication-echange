Bouin Julien, Lepretre Mathys, Paul Milleville .

Pour lancer le projet il faut utiliser les commandes suivantes :

Pour compiler:

javac Interface.java

Pour executer:

/usr/bin/env /usr/lib/jvm/jdk-19.0.2/bin/java @/tmp/cp_aoqppbnv4mlmh380nmjjn2xtv.argfile Interface


