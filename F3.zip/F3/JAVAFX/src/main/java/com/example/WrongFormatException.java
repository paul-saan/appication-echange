package com.example;

public class WrongFormatException extends Exception {
    WrongFormatException(){
        super("Wrong format");
    }
}
