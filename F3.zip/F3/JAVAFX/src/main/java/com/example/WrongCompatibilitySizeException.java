package com.example;

public class WrongCompatibilitySizeException extends Exception {
    WrongCompatibilitySizeException(){
        super("Wrong compatibility size");
    }
    
}
