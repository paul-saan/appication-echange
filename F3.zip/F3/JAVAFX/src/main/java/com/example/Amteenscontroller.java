package com.example;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Amteenscontroller {
    private Stage stage;
    private Scene scene;
    private Parent root;
}
